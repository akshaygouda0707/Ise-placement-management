# Campus-Placement-Management-System
It is a java based campus placement management system in netbeans.
